#!/usr/bin/python3

# import all other neccesary libraries here

from operator import imod
from socket import MsgFlag
import sys
import numpy as np
from std_msgs.msg import Float64
from lab1_interfaces.srv import SetNoise
from rclpy.node import Node
import rclpy

class NoiseGenerator(Node):

    def __init__(self):
        # get the rate from argument or default
        if len(sys.argv)>2: 
            self.rate = float(sys.argv[1])
        else:
            self.rate = 5.0
        # add codes here
        super().__init__('nosie_generator')
        self.publisher_cmd = self.create_publisher(Float64,'noise',10)
        self.timer = self.create_timer(1.0/self.rate,self.timer_callback)
        self.service_mode = self.create_service(SetNoise,'set_noise',self.set_noise_callback)


        # additional attributes
        self.mean = 0.0
        self.variance = 1.0
        self.get_logger().info(f'Starting {self.get_namespace()}/{self.get_name()} with the default parameter. mean: {self.mean}, variance: {self.variance}')
    
    def set_noise_callback(self,request:SetNoise.Request,response:SetNoise.Response):
        # add codes here
        self.mean = request.mean.data
        self.variance = request.variance.data

        
        return response
    
    def timer_callback(self):
        # remove pass and add codes here
        msg = Float64()
        msg.data = np.random.normal(self.mean,np.sqrt(self.variance))
        self.publisher_cmd.publish(msg)
        

def main(args=None):
    # remove pass and add codes here
    rclpy.init(args=args)
    controller = NoiseGenerator()
    rclpy.spin(controller)
    controller.destroy_node()
    rclpy.shutdown()

    
if __name__=='__main__':
    main()
