// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LAB1_INTERFACES__SRV__SET_NOISE_HPP_
#define LAB1_INTERFACES__SRV__SET_NOISE_HPP_

#include "lab1_interfaces/srv/detail/set_noise__struct.hpp"
#include "lab1_interfaces/srv/detail/set_noise__builder.hpp"
#include "lab1_interfaces/srv/detail/set_noise__traits.hpp"

#endif  // LAB1_INTERFACES__SRV__SET_NOISE_HPP_
